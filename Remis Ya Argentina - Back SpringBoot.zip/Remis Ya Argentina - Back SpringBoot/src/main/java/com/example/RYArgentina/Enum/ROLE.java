package com.example.RYArgentina.Enum;

public enum ROLE {
    ADMINISTRADOR ,
    VENDEDOR,
    USUARIO

}
