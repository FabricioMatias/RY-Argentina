package com.example.RYArgentina.Enum;

public enum ORDER_BY {
    PRECIO,
    FECHA;
}
