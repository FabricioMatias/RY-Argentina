package com.example.RYArgentina.Enum;

public enum FILTERS {
    CATEGORIA,
    DESCRIPCION,
    VENDEDOR
}
