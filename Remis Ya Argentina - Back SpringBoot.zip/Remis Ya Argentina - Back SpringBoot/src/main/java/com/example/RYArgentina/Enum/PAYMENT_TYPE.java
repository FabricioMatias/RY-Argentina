package com.example.RYArgentina.Enum;

public enum PAYMENT_TYPE {
    ACORDADO_CON_VENDEDOR,
    MERCADO_PAGO;
}
