package com.example.RYArgentina.model.DTO;

public class PreferenceItem {

    private String name;
    private Integer quantity;
    private Float price;
}
