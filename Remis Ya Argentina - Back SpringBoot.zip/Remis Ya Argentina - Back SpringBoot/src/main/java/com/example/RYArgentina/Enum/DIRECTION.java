package com.example.RYArgentina.Enum;

public enum DIRECTION {
    ASC,
    DESC;
}
