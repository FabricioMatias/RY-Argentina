package com.example.RYArgentina.Enum;

public enum VENTA_STATUS {
    PENDIENTE_PAGO,
    PAGADO,
    CANCELADO,
    REDIRECT_MP;

}
