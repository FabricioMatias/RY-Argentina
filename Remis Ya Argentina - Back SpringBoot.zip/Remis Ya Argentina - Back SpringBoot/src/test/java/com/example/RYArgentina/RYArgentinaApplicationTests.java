package com.example.RYArgentina;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RYArgentinaApplicationTests {

	@Test
	void contextLoads() {
	}

}
